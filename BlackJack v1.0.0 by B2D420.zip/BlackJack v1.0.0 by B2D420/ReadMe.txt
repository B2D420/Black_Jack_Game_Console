My first project for learning C#.

╔══════════════════════════════════════════════════════════════════════════════════════╗
║░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░Disclaimer:░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░║
║░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░║
║  I wrote this game to learn coding in C#. You can't play this game with real money.  ║
║   Nonetheless should you, or a loved one might be dealing with a gambling problem,   ║
║ I highly recommend to look for help. You should play responsibly, and not risk money ║
║    that you can't afford to lose. If you're under the age of 21, please don't play   ║
║                          this. This is not a game for kids.                          ║
╚══════════════════════════════════════════════════════════════════════════════════════╝

Feel free to download and play. If you know how to improve my code or if you find 
errors, feel free to contact me.

Looks like sound only works on Windows.

To play the game, extract the .zip file and run BlackJack.exe.


Written by B2D420 (https://github.com/B2D420/)